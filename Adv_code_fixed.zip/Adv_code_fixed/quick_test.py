import urllib.request, json
for ep in ['/api/devices', '/api/anomalies', '/api/audit-log']:
    try:
        d = json.loads(urllib.request.urlopen(f'http://localhost:5000{ep}').read())
        if ep == '/api/devices': print(f"✅ DEVICES: {len(d)} found")
        elif ep == '/api/anomalies': print(f"✅ ANOMALIES: T1={len(d['tier1'])}, T2={len(d['tier2'])}, T3={len(d['tier3'])}")
        elif ep == '/api/audit-log': print(f"✅ AUDIT LOG: {len(d['entries'])} entries")
    except Exception as e: print(f"❌ {ep}: {e}")
